
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import ProductCard from './components/ProductCard';
import CartDrawer from './components/CartDrawer';
import ChatWidget from './components/ChatWidget';
import AdminDashboard from './components/AdminDashboard';
import OrderTracking from './components/OrderTracking';
import ProductDetailsModal from './components/ProductDetailsModal';
import BottomNav from './components/BottomNav';
import Footer from './components/Footer';
import Blog from './components/Blog';
import { AuthModal } from './components/AuthModals';
import { Product, CartItem, User, Order, PaymentMethod, Category, Comment, OrderStatus, PaymentMethodConfig, SiteSettings, MarketingBanner, BlogPost, Currency } from './types';

const DEFAULT_SETTINGS: SiteSettings = {
  name: "Business Technologie",
  description: "L'excellence technologique et l'innovation au service de la performance.",
  logo_url: "",
  contact_email: "kitebajoel@gmail.com",
  contact_whatsapp: "+243 838696468",
  tax_rate: 16,
  default_currency: "USD",
  address: "Boulevard Sake, Goma Himbi 1"
};

const DEFAULT_BLOG_POSTS: BlogPost[] = [
  {
    id: 'b1',
    title: "L'ère de l'Intelligence Artificielle en RDC",
    excerpt: "Comment les processeurs NVIDIA et les puces Apple Silicon transforment le paysage du développement local.",
    content: "L'intelligence artificielle n'est plus un concept lointain...",
    author: "Tech Insight Team",
    date: "24 Mai 2024",
    image_url: "https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80&w=1200",
    category: "Innovation",
    readTime: "5 min"
  }
];

const TECH_PRODUCTS: Product[] = [
  {
    id: 'p1',
    designation: 'MacBook Pro 16" M3 Max',
    description: 'Puce M3 Max avec CPU 14 cœurs et GPU 30 cœurs, 36 Go de mémoire unifiée, 1 To SSD.',
    prix: 3499,
    devise: 'USD',
    categorie: 'Ordinateurs',
    image_url: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&q=80&w=800',
    stock: 8,
    likes: ['u1', 'u2']
  }
];

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('bt_current_user');
    return saved ? JSON.parse(saved) : null;
  });
  
  const [siteSettings, setSiteSettings] = useState<SiteSettings>(() => {
    const saved = localStorage.getItem('bt_settings');
    if (saved) return JSON.parse(saved);
    return DEFAULT_SETTINGS;
  });

  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('bt_users');
    return saved ? JSON.parse(saved) : [
      { id: 'admin-1', mail: 'joelyombikale@gmail.com', nom: 'Joel Yombikale', mot_de_passe: '12345678', role: 'admin', inscription: new Date().toISOString() }
    ];
  });

  const [isBlogView, setIsBlogView] = useState(false);
  const [isAdminView, setIsAdminView] = useState(false);
  const [isTrackOrderView, setIsTrackOrderView] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>('Toutes');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('bt_products');
    return saved && JSON.parse(saved).length > 0 ? JSON.parse(saved) : TECH_PRODUCTS;
  });

  const [blogPosts, setBlogPosts] = useState<BlogPost[]>(() => {
    const saved = localStorage.getItem('bt_blog_posts');
    return saved && JSON.parse(saved).length > 0 ? JSON.parse(saved) : DEFAULT_BLOG_POSTS;
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('bt_orders');
    return saved ? JSON.parse(saved) : [];
  });

  const [comments, setComments] = useState<Comment[]>(() => {
    const saved = localStorage.getItem('bt_comments');
    return saved ? JSON.parse(saved) : [];
  });

  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem('bt_categories');
    return saved ? JSON.parse(saved) : [
      { id: '1', designation: "Ordinateurs" },
      { id: '2', designation: "Composants" },
      { id: '3', designation: "Périphériques" },
      { id: '4', designation: "Réseautage" }
    ];
  });

  const [paymentMethods, setPaymentMethods] = useState<PaymentMethodConfig[]>(() => {
    const saved = localStorage.getItem('bt_payments');
    return saved ? JSON.parse(saved) : [
      { id: 'mpesa', name: 'M-Pesa', logo: 'https://upload.wikimedia.org/wikipedia/commons/b/b8/Vodacom_M-Pesa_Logo.svg', type: 'mobile' },
      { id: 'airtel', name: 'Airtel Money', logo: 'https://upload.wikimedia.org/wikipedia/commons/4/4d/Airtel_logo.svg', type: 'mobile' },
      { id: 'orange', name: 'Orange Money', logo: 'https://upload.wikimedia.org/wikipedia/commons/c/c8/Orange_logo.svg', type: 'mobile' },
      { id: 'paypal', name: 'PayPal', logo: 'https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg', type: 'other' },
      { id: 'equity', name: 'Equity-BCDC', logo: 'https://upload.wikimedia.org/wikipedia/commons/1/1a/Equity_Bank_Logo.png', type: 'bank' },
      { id: 'visa', name: 'Visa / Mastercard', logo: 'https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg', type: 'card' }
    ];
  });

  const [banners, setBanners] = useState<MarketingBanner[]>(() => {
    const saved = localStorage.getItem('bt_banners');
    return saved ? JSON.parse(saved) : [
      { id: 'b1', title: "Innovation Sans Limites", subtitle: "Découvrez notre nouvelle collection de matériel informatique haut de gamme.", button_text: "Explorer", image_url: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=1200", is_active: true }
    ];
  });

  useEffect(() => {
    localStorage.setItem('bt_current_user', JSON.stringify(user));
    localStorage.setItem('bt_settings', JSON.stringify(siteSettings));
    localStorage.setItem('bt_users', JSON.stringify(users));
    localStorage.setItem('bt_products', JSON.stringify(products));
    localStorage.setItem('bt_blog_posts', JSON.stringify(blogPosts));
    localStorage.setItem('bt_orders', JSON.stringify(orders));
    localStorage.setItem('bt_comments', JSON.stringify(comments));
    localStorage.setItem('bt_categories', JSON.stringify(categories));
    localStorage.setItem('bt_payments', JSON.stringify(paymentMethods));
    localStorage.setItem('bt_banners', JSON.stringify(banners));
  }, [user, siteSettings, users, products, blogPosts, orders, comments, categories, paymentMethods, banners]);

  const handleAuthSuccess = (u: User) => {
    setUser(u);
    setUsers(prev => {
      const exists = prev.find(x => x.mail === u.mail);
      return exists ? prev.map(x => x.mail === u.mail ? u : x) : [...prev, u];
    });
  };

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      return [...prev, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const handleCheckoutSuccess = (paymentMethod: PaymentMethod, customerPhone: string, currency: Currency, total: number) => {
    if (!user) return;
    const newOrder: Order = {
      id_commande: Math.random().toString(36).substr(2, 6).toUpperCase(),
      id_client: user.id,
      nom_client: user.nom,
      items: [...cart],
      prix: total,
      devise: currency,
      statut: 'confirmed',
      paymentMethod,
      customerPhone,
      createdAt: new Date().toISOString(),
      history: [{ status: 'confirmed', date: new Date().toISOString(), label: `Paiement validé en ${currency}` }]
    };
    setOrders(prev => [newOrder, ...prev]);
    setCart([]);
  };

  return (
    <div className="min-h-screen flex flex-col pb-16 md:pb-0 bg-slate-50">
      <Header 
        cartCount={cart.reduce((a, b) => a + b.quantity, 0)} 
        user={user}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenChat={() => setIsChatOpen(true)}
        onLoginClick={() => setIsAuthModalOpen(true)}
        onLogout={() => { setUser(null); setIsAdminView(false); }}
        onAdminClick={() => { setIsAdminView(true); setIsBlogView(false); setIsTrackOrderView(false); }}
        isAdminView={isAdminView}
        isTrackOrderView={isTrackOrderView}
        isBlogView={isBlogView}
        onHomeClick={() => { setIsAdminView(false); setIsTrackOrderView(false); setIsBlogView(false); }}
        onTrackOrderClick={() => { setIsTrackOrderView(true); setIsAdminView(false); setIsBlogView(false); }}
        onBlogClick={() => { setIsBlogView(true); setIsAdminView(false); setIsTrackOrderView(false); }}
      />

      <main className="flex-1">
        {isAdminView && user?.role === 'admin' ? (
          <AdminDashboard 
            users={users} 
            orders={orders} 
            products={products} 
            blogPosts={blogPosts}
            categories={categories}
            paymentMethods={paymentMethods}
            siteSettings={siteSettings}
            banners={banners}
            comments={comments}
            onSaveProduct={(p) => setProducts(prev => {
              const exists = prev.find(x => x.id === p.id);
              return exists ? prev.map(x => x.id === p.id ? { ...x, ...p } as Product : x) : [{ ...p, id: Math.random().toString() } as Product, ...prev];
            })}
            onDeleteProduct={(id) => setProducts(prev => prev.filter(p => p.id !== id))}
            onSaveBlogPost={(b) => setBlogPosts(prev => {
              const exists = prev.find(x => x.id === b.id);
              if (exists) return prev.map(x => x.id === b.id ? { ...x, ...b } as BlogPost : x);
              return [{ ...b, id: Math.random().toString(), date: new Date().toLocaleDateString('fr-FR') } as BlogPost, ...prev];
            })}
            onDeleteBlogPost={(id) => setBlogPosts(prev => prev.filter(b => b.id !== id))}
            onSaveCategory={(c) => setCategories(prev => {
              const exists = prev.find(x => x.id === c.id);
              return exists ? prev.map(x => x.id === c.id ? { ...x, ...c } as Category : x) : [...prev, { ...c, id: Math.random().toString() } as Category];
            })}
            onDeleteCategory={(id) => setCategories(prev => prev.filter(c => c.id !== id))}
            onUpdateOrderStatus={(id, s) => setOrders(prev => prev.map(o => o.id_commande === id ? { ...o, statut: s } : o))}
            onSavePaymentMethod={(pm) => setPaymentMethods(prev => {
              const exists = prev.find(x => x.id === pm.id);
              return exists ? prev.map(x => x.id === pm.id ? { ...x, ...pm } as PaymentMethodConfig : x) : [...prev, pm as PaymentMethodConfig];
            })}
            onDeletePaymentMethod={(id) => setPaymentMethods(prev => prev.filter(p => p.id !== id))}
            onSaveSiteSettings={setSiteSettings}
            onSaveBanner={(b) => setBanners(prev => {
              const exists = prev.find(x => x.id === b.id);
              return exists ? prev.map(x => x.id === b.id ? { ...x, ...b } as MarketingBanner : x) : [...prev, b as MarketingBanner];
            })}
            onDeleteBanner={(id) => setBanners(prev => prev.filter(b => b.id !== id))}
            onDeleteComment={(id) => setComments(prev => prev.filter(c => c.id !== id))}
            onSaveUser={(u) => setUsers(prev => {
              const exists = prev.find(x => x.id === u.id);
              return exists ? prev.map(x => x.id === u.id ? { ...x, ...u } as User : x) : [...prev, { ...u, id: Math.random().toString(), inscription: new Date().toISOString() } as User];
            })}
            onDeleteUser={(id) => setUsers(prev => prev.filter(u => u.id !== id))}
          />
        ) : isTrackOrderView ? (
          <OrderTracking orders={orders} user={user} onLoginClick={() => setIsAuthModalOpen(true)} />
        ) : isBlogView ? (
          <Blog posts={blogPosts} />
        ) : (
          <>
            {banners.find(b => b.is_active) && (
              <section className="relative h-[500px] overflow-hidden">
                <div className="absolute inset-0 bg-slate-900/60 z-10"></div>
                <img src={banners.find(b => b.is_active)?.image_url} className="absolute inset-0 w-full h-full object-cover animate-slow-zoom" alt="" />
                <div className="relative z-20 max-w-7xl mx-auto px-6 h-full flex flex-col justify-center items-center md:items-start text-center md:text-left">
                  <h1 className="text-5xl md:text-7xl font-black text-white mb-6 leading-tight tracking-tighter">
                    {banners.find(b => b.is_active)?.title}
                  </h1>
                  <p className="text-xl text-slate-200 mb-10 max-w-2xl font-medium">{banners.find(b => b.is_active)?.subtitle}</p>
                  <button onClick={() => document.getElementById('products-grid')?.scrollIntoView({ behavior: 'smooth' })} className="bg-blue-600 hover:bg-blue-700 text-white px-10 py-5 rounded-2xl font-black uppercase tracking-widest shadow-2xl shadow-blue-500/20 transition-all active:scale-95">
                    {banners.find(b => b.is_active)?.button_text}
                  </button>
                </div>
              </section>
            )}

            <div id="products-grid" className="max-w-7xl mx-auto px-6 py-16">
              <div className="flex justify-between items-end mb-12">
                <div>
                  <h2 className="text-3xl font-black text-slate-900 mb-2">Technologie Élite</h2>
                  <p className="text-slate-500 font-medium">Les meilleurs outils pour bâtir le futur.</p>
                </div>
                <div className="flex gap-2 bg-white p-1 rounded-2xl border border-slate-200">
                  <button onClick={() => setActiveCategory('Toutes')} className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeCategory === 'Toutes' ? 'bg-slate-900 text-white' : 'text-slate-400 hover:text-slate-600'}`}>Tous</button>
                  {categories.map(c => (
                    <button key={c.id} onClick={() => setActiveCategory(c.designation)} className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeCategory === c.designation ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-600'}`}>
                      {c.designation}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                {products.filter(p => activeCategory === 'Toutes' || p.categorie === activeCategory).map(p => (
                  <ProductCard key={p.id} product={p} onAddToCart={addToCart} onViewDetails={setSelectedProduct} />
                ))}
              </div>
            </div>
          </>
        )}
      </main>

      {!isAdminView && <Footer settings={siteSettings} categories={categories} />}

      <CartDrawer 
        isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} items={cart} user={user} paymentMethods={paymentMethods} 
        onRemove={(id) => setCart(c => c.filter(x => x.id !== id))} 
        onUpdateQuantity={(id, q) => setCart(c => c.map(x => x.id === id ? { ...x, quantity: q } : x))}
        onCheckoutSuccess={handleCheckoutSuccess} onLoginRequest={() => setIsAuthModalOpen(true)} 
        onGoToTracking={() => { setIsTrackOrderView(true); setIsBlogView(false); setIsAdminView(false); }} 
      />
      
      <ChatWidget isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />
      <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} onLoginSuccess={handleAuthSuccess} />
      
      {selectedProduct && (
        <ProductDetailsModal 
          product={selectedProduct} user={user} comments={comments.filter(c => c.id_produit === selectedProduct.id)} 
          isOpen={!!selectedProduct} onClose={() => setSelectedProduct(null)} onAddToCart={addToCart} 
          onLike={() => {}} 
          onAddComment={(pid, txt) => {
            if (!user) return;
            setComments(prev => [{ id: Math.random().toString(), id_produit: pid, id_client: user.id, nom_client: user.nom, texte: txt, date: new Date().toISOString() }, ...prev]);
          }} 
          onLoginRequest={() => setIsAuthModalOpen(true)} 
        />
      )}

      <BottomNav 
        activeView={isAdminView ? 'admin' : isTrackOrderView ? 'tracking' : 'shop'} 
        user={user} 
        onHomeClick={() => { setIsAdminView(false); setIsTrackOrderView(false); setIsBlogView(false); }} 
        onTrackOrderClick={() => { setIsTrackOrderView(true); setIsAdminView(false); setIsBlogView(false); }} 
        onLoginClick={() => setIsAuthModalOpen(true)} 
        onAdminClick={() => { setIsAdminView(true); setIsTrackOrderView(false); setIsBlogView(false); }} 
      />
    </div>
  );
};

export default App;
