
import { GoogleGenAI } from "@google/genai";
import { ChatMessage } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getTechAdvice = async (history: ChatMessage[], userMessage: string) => {
  const model = 'gemini-3-flash-preview';
  
  try {
    const chat = ai.chats.create({
      model,
      config: {
        systemInstruction: "Tu es l'expert technique de 'Business Technologie'. Aide les clients à choisir du matériel informatique (PC, serveurs, composants). Sois pro, précis et suggère des solutions basées sur leurs besoins. Réponds en Français.",
      },
    });

    // In a real app, we'd pass history to ai.chats.create if the SDK supports multi-turn easily
    // For this implementation, we simulate context by sending a structured message
    const response = await chat.sendMessage({ 
      message: userMessage 
    });

    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Désolé, je rencontre une petite difficulté technique. Comment puis-je vous aider autrement ?";
  }
};

export const generateProductDescription = async (productName: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Génère une description commerciale courte et percutante pour un produit informatique nommé : ${productName}.`,
    });
    return response.text;
  } catch (error) {
    return "Un produit d'excellence sélectionné par Business Technologie.";
  }
};
