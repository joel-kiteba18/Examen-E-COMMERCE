
export type Currency = 'USD' | 'CDF' | 'EUR';

export interface SiteSettings {
  name: string;
  description: string;
  logo_url: string;
  contact_email: string;
  contact_whatsapp: string;
  tax_rate: number;
  default_currency: Currency;
  address: string;
}

export interface MarketingBanner {
  id: string;
  title: string;
  subtitle: string;
  button_text: string;
  image_url: string;
  is_active: boolean;
}

export interface Comment {
  id: string;
  id_produit: string;
  id_client: string;
  nom_client: string;
  texte: string;
  date: string;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  date: string;
  image_url: string;
  category: string;
  readTime: string;
}

export interface Product {
  id: string;
  designation: string;
  description: string;
  prix: number;
  devise: Currency;
  categorie: string;
  image_url: string;
  stock: number;
  likes?: string[]; 
  specs?: Record<string, string>;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface PaymentMethodConfig {
  id: string;
  name: string;
  logo: string;
  type: 'mobile' | 'card' | 'bank' | 'other';
}

export type PaymentMethod = string;

export interface User {
  id: string;
  mail: string;
  nom: string;
  mot_de_passe: string;
  role: 'admin' | 'user';
  inscription: string;
}

export type OrderStatus = 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled';

export interface OrderStatusUpdate {
  status: OrderStatus;
  date: string;
  label: string;
}

export interface Order {
  id_commande: string;
  id_client: string;
  nom_client: string;
  items: CartItem[];
  prix: number;
  devise: Currency;
  statut: OrderStatus;
  paymentMethod: PaymentMethod;
  customerPhone: string;
  createdAt: string;
  updatedAt?: string;
  history: OrderStatusUpdate[];
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export interface Category {
  id: string;
  designation: string;
}
