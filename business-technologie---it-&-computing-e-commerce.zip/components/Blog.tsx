
import React from 'react';
import { BlogPost } from '../types';

interface BlogProps {
  posts: BlogPost[];
}

const Blog: React.FC<BlogProps> = ({ posts }) => {
  return (
    <div className="max-w-7xl mx-auto px-6 py-16 animate-fade-in">
      <div className="mb-16 text-center max-w-3xl mx-auto">
        <span className="text-blue-600 font-black uppercase tracking-[0.3em] text-[10px]">BT Insights</span>
        <h1 className="text-4xl md:text-5xl font-black text-slate-900 mt-4 mb-6 tracking-tight">
          Tendances & Innovations Tech
        </h1>
        <p className="text-slate-500 font-medium leading-relaxed">
          Décryptage des dernières évolutions matérielles, conseils d'experts pour votre infrastructure et avant-premières sur les produits de demain.
        </p>
      </div>

      {/* Featured Post */}
      {posts.length > 0 && (
        <div className="mb-20 group cursor-pointer overflow-hidden rounded-[3rem] bg-white border border-slate-100 shadow-2xl shadow-slate-200/50 flex flex-col lg:flex-row items-center transition-all hover:border-blue-200">
          <div className="lg:w-3/5 h-[400px] overflow-hidden">
            <img 
              src={posts[0].image_url} 
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
              alt={posts[0].title} 
            />
          </div>
          <div className="lg:w-2/5 p-12 lg:p-16">
            <div className="flex items-center gap-4 mb-6">
              <span className="bg-blue-600 text-white text-[9px] font-black uppercase tracking-widest px-3 py-1 rounded-full">À la une</span>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{posts[0].category}</span>
            </div>
            <h2 className="text-3xl font-black text-slate-900 mb-4 leading-tight group-hover:text-blue-600 transition">
              {posts[0].title}
            </h2>
            <p className="text-slate-500 mb-8 line-clamp-3 font-medium">
              {posts[0].excerpt}
            </p>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-slate-900 flex items-center justify-center text-white font-bold text-[10px]">
                  {posts[0].author.charAt(0)}
                </div>
                <div className="text-[10px] font-black uppercase tracking-widest text-slate-900">
                  {posts[0].author}
                </div>
              </div>
              <span className="text-[9px] font-black uppercase tracking-widest text-slate-400">{posts[0].readTime}</span>
            </div>
          </div>
        </div>
      )}

      {/* Grid of Posts */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
        {posts.slice(1).map((post) => (
          <div key={post.id} className="group cursor-pointer">
            <div className="aspect-[16/10] rounded-[2rem] overflow-hidden mb-6 border border-slate-100 shadow-sm">
              <img 
                src={post.image_url} 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
                alt={post.title} 
              />
            </div>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-black text-blue-600 uppercase tracking-widest">{post.category}</span>
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{post.date}</span>
              </div>
              <h3 className="text-xl font-black text-slate-900 leading-snug group-hover:text-blue-600 transition">
                {post.title}
              </h3>
              <p className="text-slate-500 text-sm font-medium line-clamp-2">
                {post.excerpt}
              </p>
              <div className="pt-4 flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-slate-900 font-bold text-[8px]">
                  {post.author.charAt(0)}
                </div>
                <span className="text-[9px] font-black uppercase tracking-widest text-slate-900">{post.author}</span>
                <span className="text-[9px] font-black text-slate-300 ml-auto">{post.readTime}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Newsletter Section */}
      <div className="mt-32 p-16 rounded-[3rem] bg-slate-900 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600/10 rounded-full blur-[100px]"></div>
        <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-12">
          <div className="max-w-md">
            <h3 className="text-3xl font-black text-white mb-4 tracking-tight">Restez à l'avant-garde.</h3>
            <p className="text-slate-400 font-medium">Inscrivez-vous pour recevoir nos analyses exclusives directement dans votre boîte mail.</p>
          </div>
          <div className="w-full lg:w-auto flex flex-col sm:flex-row gap-4">
            <input 
              type="email" 
              placeholder="votre@mail.com" 
              className="px-8 py-5 rounded-2xl bg-white/5 border border-white/10 text-white font-bold outline-none focus:ring-2 focus:ring-blue-600 min-w-[300px]"
            />
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-10 py-5 rounded-2xl font-black uppercase tracking-widest transition-all">
              S'abonner
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Blog;
