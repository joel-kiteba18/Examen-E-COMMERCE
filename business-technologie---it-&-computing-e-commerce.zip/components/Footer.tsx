
import React from 'react';
import { SiteSettings, Category } from '../types';

interface FooterProps {
  settings: SiteSettings;
  categories: Category[];
}

const Footer: React.FC<FooterProps> = ({ settings, categories }) => {
  // Nettoyage du numéro pour le lien wa.me (doit contenir uniquement des chiffres, sans le + ni espaces)
  const whatsappLink = `https://wa.me/${settings.contact_whatsapp.replace(/\D/g, '')}`;
  
  return (
    <footer className="bg-slate-900 text-slate-400 py-20 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-16">
          
          {/* Colonne 1: Localisation & Identité */}
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <div className="bg-blue-600 p-2 rounded-lg text-white font-bold text-xl">BT</div>
              <span className="text-xl font-black tracking-tight text-white uppercase">
                Business Technologie
              </span>
            </div>
            <p className="text-sm leading-relaxed max-w-xs">
              {settings.description} Leader de l'innovation et de l'équipement informatique de pointe en République Démocratique du Congo.
            </p>
            <div className="pt-4 space-y-4">
              <div className="flex items-start gap-4">
                <span className="text-xl">📍</span>
                <div>
                  <h4 className="text-white font-bold text-sm uppercase tracking-widest mb-1">Siège Social</h4>
                  <p className="text-sm italic">{settings.address}</p>
                </div>
              </div>
              <a 
                href={`https://www.google.com/maps/search/${encodeURIComponent(settings.address)}`} 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-blue-500 font-bold text-[10px] uppercase tracking-[0.2em] hover:text-blue-400 transition"
              >
                Ouvrir dans Google Maps 
                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </a>
            </div>
          </div>

          {/* Colonne 2: Service Client & Contact */}
          <div className="space-y-8">
            <h3 className="text-white font-black uppercase tracking-[0.3em] text-xs">Assistance & Ventes</h3>
            <div className="space-y-6">
              <a 
                href={whatsappLink} 
                target="_blank" 
                rel="noopener noreferrer"
                className="group flex items-center gap-4 p-4 rounded-2xl bg-slate-800/50 border border-slate-700 hover:border-blue-500 transition-all"
                title="Démarrer une discussion WhatsApp"
              >
                <div className="w-10 h-10 bg-emerald-500/10 text-emerald-500 rounded-xl flex items-center justify-center text-xl group-hover:scale-110 transition">💬</div>
                <div>
                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-500">WhatsApp Business</p>
                  <p className="text-white font-bold">{settings.contact_whatsapp}</p>
                </div>
              </a>
              <a 
                href={`mailto:${settings.contact_email}`} 
                className="group flex items-center gap-4 p-4 rounded-2xl bg-slate-800/50 border border-slate-700 hover:border-blue-500 transition-all"
                title="Envoyer un e-mail au support"
              >
                <div className="w-10 h-10 bg-blue-500/10 text-blue-500 rounded-xl flex items-center justify-center text-xl group-hover:scale-110 transition">✉️</div>
                <div>
                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-500">Support Technique</p>
                  <p className="text-white font-bold">{settings.contact_email}</p>
                </div>
              </a>
              <div className="flex items-center gap-4 px-4 text-[10px] font-black uppercase tracking-widest text-slate-500">
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                Disponible : 7jours-7 / 24h-24
              </div>
            </div>
          </div>

          {/* Colonne 3: Liens & Rayons */}
          <div className="space-y-8">
            <h3 className="text-white font-black uppercase tracking-[0.3em] text-xs">Rayons Populaires</h3>
            <div className="grid grid-cols-1 gap-3">
              {categories.slice(0, 6).map((cat) => (
                <button 
                  key={cat.id} 
                  className="text-left text-sm hover:text-white hover:translate-x-2 transition-all duration-300 flex items-center gap-2 group"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-700 group-hover:bg-blue-500 transition-colors"></span>
                  {cat.designation}
                </button>
              ))}
            </div>
            <div className="pt-4 border-t border-slate-800">
              <h4 className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-4">Modes de Paiement</h4>
              <div className="flex gap-4 grayscale opacity-40">
                <img src="https://upload.wikimedia.org/wikipedia/commons/c/c8/Orange_logo.svg" className="h-5" alt="Orange Money" />
                <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg" className="h-4" alt="Visa" />
                <span className="text-[10px] font-black uppercase">Mobile Money</span>
              </div>
            </div>
          </div>
        </div>

        {/* Barre de Copyright */}
        <div className="mt-20 pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-600">
            © {new Date().getFullYear()} {settings.name} — Tous droits réservés.
          </p>
          <div className="flex gap-8 text-[10px] font-black uppercase tracking-[0.2em]">
            <button className="hover:text-white transition">CGV & Garanties</button>
            <button className="hover:text-white transition">Politique de Confidentialité</button>
            <span className="text-blue-500">Made in RDC 🇨🇩</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
