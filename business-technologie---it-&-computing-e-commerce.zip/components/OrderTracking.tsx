
import React from 'react';
import { Order, User, OrderStatus } from '../types';

interface OrderTrackingProps {
  orders: Order[];
  user: User | null;
  onLoginClick: () => void;
}

const OrderTracking: React.FC<OrderTrackingProps> = ({ orders, user, onLoginClick }) => {
  const userOrders = user ? [...orders].filter(o => o.id_client === user.id).sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  ) : [];

  const activeOrders = userOrders.filter(o => o.statut !== 'delivered' && o.statut !== 'cancelled');
  const completedOrders = userOrders.filter(o => o.statut === 'delivered' || o.statut === 'cancelled');

  const getStatusLabel = (status: OrderStatus) => {
    switch (status) {
      case 'pending': return 'Paiement en attente';
      case 'confirmed': return 'Paiement validé';
      case 'processing': return 'Préparation en entrepôt';
      case 'shipped': return 'En transit / Livraison';
      case 'delivered': return 'Livré avec succès';
      case 'cancelled': return 'Commande annulée';
      default: return status;
    }
  };

  const getStatusColor = (status: OrderStatus) => {
    switch (status) {
      case 'delivered': return 'text-emerald-600 bg-emerald-50 border-emerald-100';
      case 'shipped': return 'text-blue-600 bg-blue-50 border-blue-100';
      case 'processing': return 'text-indigo-600 bg-indigo-50 border-indigo-100';
      case 'cancelled': return 'text-red-600 bg-red-50 border-red-100';
      default: return 'text-amber-600 bg-amber-50 border-amber-100';
    }
  };

  const steps: { id: OrderStatus; label: string; icon: string; desc: string }[] = [
    { id: 'confirmed', label: 'Validation', icon: '💳', desc: 'Paiement reçu et vérifié' },
    { id: 'processing', label: 'Logistique', icon: '🛠️', desc: 'Préparation technique de votre matériel' },
    { id: 'shipped', label: 'Expédition', icon: '🚚', desc: 'Colis confié à notre transporteur' },
    { id: 'delivered', label: 'Réception', icon: '🏠', desc: 'Matériel livré à destination' }
  ];

  const calculateProgress = (status: OrderStatus) => {
    const weights: Record<string, number> = { 'pending': 5, 'confirmed': 25, 'processing': 50, 'shipped': 75, 'delivered': 100, 'cancelled': 0 };
    return weights[status] || 0;
  };

  const isStepDone = (currentStatus: OrderStatus, stepId: OrderStatus) => {
    const sequence: OrderStatus[] = ['pending', 'confirmed', 'processing', 'shipped', 'delivered'];
    return sequence.indexOf(currentStatus) >= sequence.indexOf(stepId);
  };

  const isStepCurrent = (currentStatus: OrderStatus, stepId: OrderStatus) => currentStatus === stepId;

  const renderOrderCard = (order: Order) => (
    <div key={order.id_commande} className="bg-white rounded-[2.5rem] shadow-xl shadow-slate-200/40 border border-slate-100 overflow-hidden animate-fade-in group hover:border-blue-200 transition-colors duration-500">
      {/* En-tête de la carte */}
      <div className="p-8 bg-slate-50/50 border-b border-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl shadow-sm border ${order.statut === 'delivered' ? 'bg-emerald-500 text-white border-emerald-400' : 'bg-white text-blue-600 border-slate-200'}`}>
            {order.statut === 'delivered' ? '✓' : '📦'}
          </div>
          <div>
            <div className="flex items-center gap-3">
              <h4 className="text-xl font-black text-slate-900 tracking-tight uppercase">BT-{order.id_commande}</h4>
              <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase border tracking-widest ${getStatusColor(order.statut)}`}>
                {getStatusLabel(order.statut)}
              </span>
            </div>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">
              Commande du {new Date(order.createdAt).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })}
            </p>
          </div>
        </div>
        <div className="flex flex-col md:items-end">
          <span className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">Montant Transaction</span>
          <span className="text-2xl font-black text-slate-900">{order.prix.toLocaleString()} <span className="text-sm text-blue-600">{order.devise || 'USD'}</span></span>
        </div>
      </div>

      {/* Barre de progression globale */}
      <div className="px-8 pt-8">
        <div className="flex justify-between items-end mb-2">
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Progression du parcours</span>
          <span className="text-xs font-black text-blue-600">{calculateProgress(order.statut)}%</span>
        </div>
        <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-blue-500 to-indigo-600 transition-all duration-1000 ease-out"
            style={{ width: `${calculateProgress(order.statut)}%` }}
          />
        </div>
      </div>

      {/* Parcours Interactif (Timeline) */}
      <div className="p-8 grid grid-cols-1 lg:grid-cols-4 gap-8">
        {steps.map((step, idx) => {
          const done = isStepDone(order.statut, step.id);
          const current = isStepCurrent(order.statut, step.id);
          const historyEntry = order.history.find(h => h.status === step.id);

          return (
            <div key={step.id} className={`relative flex flex-row lg:flex-col items-start lg:items-center gap-4 lg:text-center p-4 rounded-3xl transition-all ${current ? 'bg-blue-50/50 ring-1 ring-blue-100' : ''}`}>
              <div className={`shrink-0 w-12 h-12 rounded-2xl flex items-center justify-center text-xl border-2 transition-all duration-500 z-10 ${
                done 
                  ? 'bg-blue-600 border-blue-600 text-white shadow-lg shadow-blue-200' 
                  : 'bg-white border-slate-100 text-slate-300'
              } ${current ? 'scale-110 animate-pulse' : ''}`}>
                {done ? '✓' : step.icon}
              </div>
              
              <div className="flex-1">
                <h5 className={`text-xs font-black uppercase tracking-widest ${done ? 'text-slate-900' : 'text-slate-300'}`}>
                  {step.label}
                </h5>
                <p className="text-[9px] text-slate-400 font-medium leading-tight mt-1 hidden lg:block">
                  {step.desc}
                </p>
                {historyEntry && (
                  <p className="text-[9px] font-black text-blue-500 uppercase mt-2">
                    {new Date(historyEntry.date).toLocaleDateString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Journal d'Activité */}
      <div className="px-8 pb-8">
        <div className="bg-slate-50/50 rounded-3xl p-6 border border-slate-100">
          <div className="flex items-center gap-2 mb-4">
            <span className="w-2 h-2 bg-blue-500 rounded-full animate-ping"></span>
            <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Journal Logistique en temps réel</h5>
          </div>
          <div className="space-y-4">
            {order.history.slice().reverse().map((event, idx) => (
              <div key={idx} className="flex gap-4">
                <div className="text-[10px] font-black text-slate-400 w-24 pt-0.5">
                  {new Date(event.date).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' })}
                </div>
                <div className="flex-1">
                  <p className="text-xs font-bold text-slate-700">{event.label}</p>
                  <p className="text-[9px] text-slate-400 uppercase font-black mt-0.5">Statut validé par l'entrepôt BT</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto px-4 py-12 animate-fade-in pb-32">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-12">
        <div>
          <h2 className="text-4xl font-black text-slate-900 tracking-tight mb-2">Centre de Suivi <span className="text-blue-600">BT</span></h2>
          <p className="text-slate-500 font-medium">Votre matériel informatique est entre de bonnes mains.</p>
        </div>
        {!user && (
          <button 
            onClick={onLoginClick}
            className="bg-slate-900 text-white px-8 py-4 rounded-2xl font-black uppercase tracking-widest hover:bg-blue-600 transition shadow-xl active:scale-95 flex items-center gap-3"
          >
            Accéder à mon compte
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          </button>
        )}
      </div>

      {!user ? (
        <div className="bg-white p-16 rounded-[3rem] shadow-2xl shadow-slate-200/50 border border-slate-100 text-center">
          <div className="w-24 h-24 bg-blue-50 text-blue-600 rounded-[2rem] flex items-center justify-center mx-auto mb-8 rotate-6">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
            </svg>
          </div>
          <h3 className="text-3xl font-black text-slate-900 mb-4">Consultation Réservée</h3>
          <p className="text-slate-500 mb-10 max-w-md mx-auto font-medium leading-relaxed">Veuillez vous identifier pour accéder au parcours en temps réel de vos commandes et consulter vos factures professionnelles.</p>
          <button 
            onClick={onLoginClick}
            className="bg-blue-600 text-white px-12 py-5 rounded-3xl font-black uppercase tracking-widest hover:bg-blue-700 transition shadow-2xl shadow-blue-200"
          >
            Se Connecter
          </button>
        </div>
      ) : userOrders.length === 0 ? (
        <div className="bg-white p-24 rounded-[3rem] shadow-2xl shadow-slate-200/50 border border-slate-100 text-center">
          <div className="text-7xl mb-8 opacity-50">🚀</div>
          <h3 className="text-2xl font-black text-slate-900 mb-2">Prêt pour votre premier déploiement ?</h3>
          <p className="text-slate-500 font-medium">Vos commandes actives s'afficheront ici dès leur validation.</p>
        </div>
      ) : (
        <div className="space-y-16">
          {activeOrders.length > 0 && (
            <div>
              <div className="flex items-center gap-4 mb-8">
                <div className="h-px bg-slate-200 flex-1"></div>
                <h3 className="text-[10px] font-black text-blue-600 uppercase tracking-[0.3em] whitespace-nowrap">Expéditions Actives</h3>
                <div className="h-px bg-slate-200 flex-1"></div>
              </div>
              <div className="space-y-8">
                {activeOrders.map(renderOrderCard)}
              </div>
            </div>
          )}

          {completedOrders.length > 0 && (
            <div>
              <div className="flex items-center gap-4 mb-8">
                <div className="h-px bg-slate-200 flex-1"></div>
                <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] whitespace-nowrap">Historique des livraisons</h3>
                <div className="h-px bg-slate-200 flex-1"></div>
              </div>
              <div className="space-y-8 opacity-70 grayscale-[0.5] hover:opacity-100 hover:grayscale-0 transition-all duration-500">
                {completedOrders.map(renderOrderCard)}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default OrderTracking;
