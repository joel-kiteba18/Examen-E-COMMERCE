
import React from 'react';
import { PaymentMethod, PaymentMethodConfig } from '../types';

interface PaymentMethodSelectorProps {
  selected: PaymentMethod;
  onSelect: (method: PaymentMethod) => void;
  availableMethods: PaymentMethodConfig[];
}

const PaymentMethodSelector: React.FC<PaymentMethodSelectorProps> = ({ selected, onSelect, availableMethods }) => {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
      {availableMethods.map((method) => (
        <button
          key={method.id}
          type="button"
          onClick={() => onSelect(method.id)}
          className={`relative flex flex-col items-center justify-center p-3 rounded-xl border-2 transition-all h-24 ${
            selected === method.id 
              ? 'border-blue-600 bg-blue-50 shadow-md' 
              : 'border-slate-100 bg-white hover:border-slate-200'
          }`}
        >
          <div className="w-10 h-10 flex items-center justify-center mb-2 overflow-hidden">
            <img 
              src={method.logo} 
              alt={method.name} 
              className="w-full h-full object-contain" 
              onError={(e) => {
                (e.target as HTMLImageElement).src = 'https://via.placeholder.com/40?text=BT';
              }}
            />
          </div>
          <span className="text-[10px] font-bold text-slate-800 text-center leading-tight">{method.name}</span>
          {selected === method.id && (
            <div className="absolute top-1 right-1 bg-blue-600 text-white rounded-full p-0.5">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M5 13l4 4L19 7" />
              </svg>
            </div>
          )}
        </button>
      ))}
    </div>
  );
};

export default PaymentMethodSelector;
