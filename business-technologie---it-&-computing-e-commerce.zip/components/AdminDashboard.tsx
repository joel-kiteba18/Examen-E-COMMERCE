
import React, { useState, useRef } from 'react';
import { User, Order, Product, Category, OrderStatus, PaymentMethodConfig, SiteSettings, MarketingBanner, Comment, BlogPost } from '../types';

interface AdminDashboardProps {
  users: User[];
  orders: Order[];
  products: Product[];
  categories: Category[];
  blogPosts: BlogPost[];
  paymentMethods: PaymentMethodConfig[];
  siteSettings: SiteSettings;
  banners: MarketingBanner[];
  comments: Comment[];
  onSaveProduct: (p: Partial<Product>) => void;
  onDeleteProduct: (id: string) => void;
  onSaveCategory: (c: Partial<Category>) => void;
  onDeleteCategory: (id: string) => void;
  onSaveBlogPost: (b: Partial<BlogPost>) => void;
  onDeleteBlogPost: (id: string) => void;
  onUpdateOrderStatus: (id: string, s: OrderStatus) => void;
  onSavePaymentMethod: (pm: Partial<PaymentMethodConfig>) => void;
  onDeletePaymentMethod: (id: string) => void;
  onSaveSiteSettings: (s: SiteSettings) => void;
  onSaveBanner: (b: Partial<MarketingBanner>) => void;
  onDeleteBanner: (id: string) => void;
  onDeleteComment: (id: string) => void;
  onSaveUser: (u: Partial<User>) => void;
  onDeleteUser: (id: string) => void;
}

type AdminTab = 'orders' | 'inventory' | 'products' | 'categories' | 'blog' | 'marketing' | 'reviews' | 'payments' | 'users' | 'settings';

const AdminDashboard: React.FC<AdminDashboardProps> = (props) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('orders');
  const [editingItem, setEditingItem] = useState<any>(null);
  const [confirmDelete, setConfirmDelete] = useState<{ id: string; type: AdminTab } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDelete = () => {
    if (!confirmDelete) return;
    const { id, type } = confirmDelete;
    if (type === 'products') props.onDeleteProduct(id);
    if (type === 'categories') props.onDeleteCategory(id);
    if (type === 'blog') props.onDeleteBlogPost(id);
    if (type === 'payments') props.onDeletePaymentMethod(id);
    if (type === 'marketing') props.onDeleteBanner(id);
    if (type === 'reviews') props.onDeleteComment(id);
    if (type === 'users') props.onDeleteUser(id);
    setConfirmDelete(null);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditingItem({ ...editingItem, image_url: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const navItems: { id: AdminTab; label: string; icon: string }[] = [
    { id: 'orders', label: 'Ventes', icon: '💰' },
    { id: 'inventory', label: 'Stocks', icon: '📦' },
    { id: 'products', label: 'Produits', icon: '🏷️' },
    { id: 'categories', label: 'Rayons', icon: '📁' },
    { id: 'blog', label: 'Blog', icon: '✍️' },
    { id: 'marketing', label: 'Marketing', icon: '🚀' },
    { id: 'reviews', label: 'Avis', icon: '💬' },
    { id: 'payments', label: 'Paiements', icon: '💳' },
    { id: 'users', label: 'Clients', icon: '👥' },
    { id: 'settings', label: 'Configuration', icon: '⚙️' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-6 py-10 animate-fade-in pb-32">
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Sidebar */}
        <aside className="lg:w-72 flex flex-row lg:flex-col gap-2 overflow-x-auto lg:overflow-visible pb-4 no-scrollbar">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-4 px-6 py-4 rounded-2xl text-[11px] font-black uppercase tracking-[0.1em] transition-all whitespace-nowrap ${
                activeTab === item.id 
                  ? 'bg-slate-900 text-white shadow-2xl shadow-slate-200 scale-[1.02]' 
                  : 'bg-white text-slate-400 hover:bg-slate-50 border border-slate-100'
              }`}
            >
              <span className="text-xl">{item.icon}</span>
              {item.label}
            </button>
          ))}
        </aside>

        {/* Content Area */}
        <div className="flex-1 bg-white rounded-[3rem] shadow-2xl shadow-slate-200/50 border border-slate-100 overflow-hidden min-h-[700px]">
          <div className="p-10 border-b bg-slate-50/30 flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-black text-slate-900 uppercase tracking-tighter">{activeTab}</h2>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">BT ERP System v5.0</p>
            </div>
            {['products', 'categories', 'payments', 'marketing', 'blog', 'users'].includes(activeTab) && (
              <button 
                onClick={() => setEditingItem({})} 
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-blue-500/20 transition-all active:scale-95"
              >
                + Nouveau {activeTab === 'blog' ? 'Article' : activeTab === 'users' ? 'Client' : 'Élément'}
              </button>
            )}
          </div>

          <div className="p-10">
            {/* Categories Management Table */}
            {activeTab === 'categories' && (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-separate border-spacing-y-4">
                  <thead>
                    <tr className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">
                      <th className="px-6 pb-2">Désignation du Rayon</th>
                      <th className="px-6 pb-2 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {props.categories.map(cat => (
                      <tr key={cat.id} className="bg-slate-50/50 hover:bg-slate-50 transition group">
                        <td className="px-6 py-5 rounded-l-[1.5rem] border-y border-l">
                          <div className="font-black text-slate-900 text-sm">{cat.designation}</div>
                        </td>
                        <td className="px-6 py-5 border-y border-r rounded-r-[1.5rem] text-right">
                          <button onClick={() => setEditingItem(cat)} className="text-blue-600 font-bold text-xs mr-4 hover:underline">Modifier</button>
                          <button onClick={() => setConfirmDelete({id: cat.id, type: 'categories'})} className="text-red-400 font-bold text-xs hover:text-red-600">Supprimer</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Users Management Table */}
            {activeTab === 'users' && (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-separate border-spacing-y-4">
                  <thead>
                    <tr className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">
                      <th className="px-6 pb-2">Client / Email</th>
                      <th className="px-6 pb-2">Rôle</th>
                      <th className="px-6 pb-2">Inscription</th>
                      <th className="px-6 pb-2 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {props.users.map(u => (
                      <tr key={u.id} className="bg-slate-50/50 hover:bg-slate-50 transition group">
                        <td className="px-6 py-5 rounded-l-[1.5rem] border-y border-l">
                          <div className="font-black text-slate-900 text-sm leading-none mb-1">{u.nom}</div>
                          <div className="text-[10px] text-slate-400 font-bold">{u.mail}</div>
                        </td>
                        <td className="px-6 py-5 border-y text-[10px] font-black uppercase">
                          <span className={`px-3 py-1 rounded-full ${u.role === 'admin' ? 'bg-orange-100 text-orange-600' : 'bg-blue-100 text-blue-600'}`}>
                            {u.role}
                          </span>
                        </td>
                        <td className="px-6 py-5 border-y text-[10px] font-bold text-slate-500">{new Date(u.inscription).toLocaleDateString()}</td>
                        <td className="px-6 py-5 border-y border-r rounded-r-[1.5rem] text-right">
                          <button onClick={() => setEditingItem(u)} className="text-blue-600 font-bold text-xs mr-4 hover:underline">Modifier</button>
                          <button onClick={() => setConfirmDelete({id: u.id, type: 'users'})} className="text-red-400 font-bold text-xs hover:text-red-600">Effacer</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {activeTab === 'blog' && (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-separate border-spacing-y-4">
                  <thead>
                    <tr className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">
                      <th className="px-6 pb-2">Aperçu</th>
                      <th className="px-6 pb-2">Titre / Infos</th>
                      <th className="px-6 pb-2">Auteur & Date</th>
                      <th className="px-6 pb-2 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {props.blogPosts.map(post => (
                      <tr key={post.id} className="bg-slate-50/50 hover:bg-slate-50 transition group">
                        <td className="px-6 py-5 rounded-l-[1.5rem] border-y border-l">
                          <img src={post.image_url} className="w-14 h-14 rounded-xl object-cover border" alt="" />
                        </td>
                        <td className="px-6 py-5 border-y">
                          <div className="font-black text-slate-900 text-sm leading-tight mb-1">{post.title}</div>
                          <span className="bg-blue-100 text-blue-600 px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest">
                            {post.category}
                          </span>
                        </td>
                        <td className="px-6 py-5 border-y">
                          <div className="text-xs font-black text-slate-900">Par {post.author}</div>
                          <div className="text-[10px] font-bold text-slate-400 uppercase mt-0.5">{post.date} • {post.readTime}</div>
                        </td>
                        <td className="px-6 py-5 border-y border-r rounded-r-[1.5rem] text-right">
                          <button onClick={() => setEditingItem(post)} className="text-blue-600 font-bold text-xs mr-4 hover:underline">Modifier</button>
                          <button onClick={() => setConfirmDelete({id: post.id, type: 'blog'})} className="text-red-400 font-bold text-xs hover:text-red-600">Effacer</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {activeTab === 'orders' && (
              <div className="space-y-6">
                {props.orders.length === 0 ? (
                  <div className="py-20 text-center text-slate-400 font-bold uppercase text-xs">Aucune commande enregistrée</div>
                ) : (
                  props.orders.map(o => (
                    <div key={o.id_commande} className="p-8 bg-slate-50 rounded-[2rem] border border-slate-100 flex flex-col md:flex-row justify-between items-center gap-6 group hover:border-blue-200 transition-all">
                      <div className="flex gap-4 items-center">
                        <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-sm text-xl border">🛒</div>
                        <div>
                          <div className="font-black text-slate-900">BT-ORD-{o.id_commande}</div>
                          <div className="text-[10px] text-slate-400 font-bold uppercase">{o.nom_client} • {new Date(o.createdAt).toLocaleDateString()}</div>
                        </div>
                      </div>
                      <div className="flex flex-col md:items-center">
                         <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">État actuel</span>
                         <select 
                            value={o.statut} 
                            onChange={(e) => props.onUpdateOrderStatus(o.id_commande, e.target.value as any)} 
                            className={`bg-white px-4 py-2 rounded-xl text-[10px] font-black uppercase border-none shadow-sm cursor-pointer outline-none ${o.statut === 'delivered' ? 'text-emerald-600' : 'text-blue-600'}`}
                          >
                          <option value="confirmed">Confirmée</option>
                          <option value="processing">Préparation</option>
                          <option value="shipped">Expédiée</option>
                          <option value="delivered">Livrée</option>
                          <option value="cancelled">Annulée</option>
                        </select>
                      </div>
                      <div className="text-right">
                        <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Montant</div>
                        <div className="font-black text-slate-900 text-xl">{o.prix.toLocaleString()} <span className="text-xs text-blue-600">USD</span></div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {activeTab === 'products' && (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-separate border-spacing-y-4">
                  <thead>
                    <tr className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">
                      <th className="px-6 pb-2">Produit</th>
                      <th className="px-6 pb-2">Rayon</th>
                      <th className="px-6 pb-2">Prix</th>
                      <th className="px-6 pb-2 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {props.products.map(p => (
                      <tr key={p.id} className="bg-slate-50/50 hover:bg-slate-50 transition group">
                        <td className="px-6 py-5 rounded-l-[1.5rem] border-y border-l">
                          <div className="flex items-center gap-4">
                            <img src={p.image_url} className="w-12 h-12 rounded-xl object-cover border" alt="" />
                            <div className="font-black text-slate-900 text-sm leading-none">{p.designation}</div>
                          </div>
                        </td>
                        <td className="px-6 py-5 border-y text-[10px] font-black uppercase text-slate-400">{p.categorie}</td>
                        <td className="px-6 py-5 border-y font-black text-slate-900">{p.prix.toLocaleString()} USD</td>
                        <td className="px-6 py-5 border-y border-r rounded-r-[1.5rem] text-right">
                          <button onClick={() => setEditingItem(p)} className="text-blue-600 font-bold text-xs mr-4 hover:underline">Modifier</button>
                          <button onClick={() => setConfirmDelete({id: p.id, type: 'products'})} className="text-red-400 font-bold text-xs hover:text-red-600">Supprimer</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Confirmation Modals */}
      {confirmDelete && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-md" onClick={() => setConfirmDelete(null)} />
          <div className="relative w-full max-w-sm bg-white rounded-[3rem] p-12 text-center shadow-2xl animate-fade-in-up">
            <h3 className="text-2xl font-black text-slate-900 mb-2 tracking-tighter">Confirmer ?</h3>
            <p className="text-slate-500 text-sm font-medium mb-10 leading-relaxed">Cette action effacera définitivement l'élément sélectionné.</p>
            <div className="flex gap-4">
              <button onClick={() => setConfirmDelete(null)} className="flex-1 px-6 py-4 rounded-2xl bg-slate-100 text-slate-600 font-black uppercase text-[10px] tracking-widest hover:bg-slate-200 transition">Annuler</button>
              <button onClick={handleDelete} className="flex-1 px-6 py-4 rounded-2xl bg-red-600 text-white font-black uppercase text-[10px] tracking-widest shadow-2xl transition hover:bg-red-700">Supprimer</button>
            </div>
          </div>
        </div>
      )}

      {/* Editing Modal for All Tabs */}
      {editingItem && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-md" onClick={() => setEditingItem(null)} />
          <div className="relative w-full max-w-3xl bg-white rounded-[3rem] shadow-2xl overflow-hidden animate-fade-in-up">
            <div className="p-10 md:p-14 overflow-y-auto max-h-[90vh]">
               <div className="flex justify-between items-center mb-10">
                 <div>
                    <h3 className="text-3xl font-black text-slate-900 uppercase tracking-tighter">{editingItem.id ? 'Modifier' : 'Nouveau'}</h3>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Section: {activeTab}</p>
                 </div>
                 <button onClick={() => setEditingItem(null)} className="p-4 bg-slate-50 rounded-2xl text-slate-400 hover:text-slate-900 transition">✕</button>
               </div>
               
               <div className="space-y-8">
                  {/* Category Edit Form */}
                  {activeTab === 'categories' && (
                    <div>
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Nom du Rayon</label>
                      <input type="text" placeholder="Ex: Ordinateurs, Serveurs..." value={editingItem.designation || ''} onChange={(e) => setEditingItem({...editingItem, designation: e.target.value})} className="w-full p-6 bg-slate-50 border border-slate-100 rounded-[1.5rem] font-bold outline-none focus:ring-2 focus:ring-blue-500" />
                    </div>
                  )}

                  {/* Users Edit Form */}
                  {activeTab === 'users' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="md:col-span-2">
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Nom Complet</label>
                        <input type="text" placeholder="Joel Yombikale" value={editingItem.nom || ''} onChange={(e) => setEditingItem({...editingItem, nom: e.target.value})} className="w-full p-6 bg-slate-50 border border-slate-100 rounded-[1.5rem] font-bold outline-none focus:ring-2 focus:ring-blue-500" />
                      </div>
                      <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Email</label>
                        <input type="email" placeholder="client@exemple.com" value={editingItem.mail || ''} onChange={(e) => setEditingItem({...editingItem, mail: e.target.value})} className="w-full p-5 bg-slate-50 border border-slate-100 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-blue-500" />
                      </div>
                      <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Mot de passe</label>
                        <input type="password" placeholder="••••••••" value={editingItem.mot_de_passe || ''} onChange={(e) => setEditingItem({...editingItem, mot_de_passe: e.target.value})} className="w-full p-5 bg-slate-50 border border-slate-100 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-blue-500" />
                      </div>
                      <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Rôle Système</label>
                        <select value={editingItem.role || 'user'} onChange={(e) => setEditingItem({...editingItem, role: e.target.value})} className="w-full p-5 bg-slate-50 border border-slate-100 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-blue-500">
                          <option value="user">Utilisateur Standard</option>
                          <option value="admin">Administrateur</option>
                        </select>
                      </div>
                    </div>
                  )}

                  {/* Blog Edit Form */}
                  {activeTab === 'blog' && (
                    <>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="md:col-span-2">
                          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Titre de l'article</label>
                          <input type="text" placeholder="Entrez un titre percutant..." value={editingItem.title || ''} onChange={(e) => setEditingItem({...editingItem, title: e.target.value})} className="w-full p-6 bg-slate-50 border border-slate-100 rounded-[1.5rem] font-bold outline-none focus:ring-2 focus:ring-blue-500" />
                        </div>
                        <div>
                          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Catégorie</label>
                          <input type="text" placeholder="Ex: Innovation, Réseau..." value={editingItem.category || ''} onChange={(e) => setEditingItem({...editingItem, category: e.target.value})} className="w-full p-5 bg-slate-50 border border-slate-100 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-blue-500" />
                        </div>
                        <div>
                          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Auteur</label>
                          <input type="text" placeholder="Nom de l'auteur" value={editingItem.author || ''} onChange={(e) => setEditingItem({...editingItem, author: e.target.value})} className="w-full p-5 bg-slate-50 border border-slate-100 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-blue-500" />
                        </div>
                        <div>
                          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Date de publication</label>
                          <input type="text" placeholder="Ex: 24 Mai 2024" value={editingItem.date || ''} onChange={(e) => setEditingItem({...editingItem, date: e.target.value})} className="w-full p-5 bg-slate-50 border border-slate-100 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-blue-500" />
                        </div>
                        <div>
                          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Temps de lecture</label>
                          <input type="text" placeholder="Ex: 5 min" value={editingItem.readTime || ''} onChange={(e) => setEditingItem({...editingItem, readTime: e.target.value})} className="w-full p-5 bg-slate-50 border border-slate-100 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-blue-500" />
                        </div>
                      </div>

                      <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Résumé court (Extrait)</label>
                        <textarea placeholder="Petite introduction de l'article..." value={editingItem.excerpt || ''} onChange={(e) => setEditingItem({...editingItem, excerpt: e.target.value})} className="w-full p-6 bg-slate-50 border border-slate-100 rounded-[1.5rem] font-bold h-24 outline-none focus:ring-2 focus:ring-blue-500" />
                      </div>

                      <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Contenu de l'article</label>
                        <textarea placeholder="Rédigez le corps de votre article ici..." value={editingItem.content || ''} onChange={(e) => setEditingItem({...editingItem, content: e.target.value})} className="w-full p-6 bg-slate-50 border border-slate-100 rounded-[1.5rem] font-bold h-64 outline-none focus:ring-2 focus:ring-blue-500" />
                      </div>

                      <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 ml-1">Image d'illustration</label>
                        <div className="flex flex-col md:flex-row gap-6">
                          <div 
                            onClick={() => fileInputRef.current?.click()}
                            className="flex-1 border-2 border-dashed border-slate-200 rounded-[2rem] p-8 flex flex-col items-center justify-center gap-3 cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-all group"
                          >
                            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
                            <div className="text-3xl group-hover:scale-110 transition">📷</div>
                            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Parcourir les fichiers</p>
                          </div>
                          {editingItem.image_url && (
                            <div className="w-full md:w-48 h-48 rounded-[2rem] overflow-hidden border relative group shadow-lg">
                              <img src={editingItem.image_url} className="w-full h-full object-cover" alt="Preview" />
                              <button onClick={() => setEditingItem({...editingItem, image_url: ''})} className="absolute top-2 right-2 bg-red-600 text-white p-2 rounded-xl opacity-0 group-hover:opacity-100 transition">✕</button>
                            </div>
                          )}
                        </div>
                      </div>
                    </>
                  )}

                  {/* Product Form */}
                  {activeTab === 'products' && (
                    <>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="md:col-span-2">
                          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Désignation</label>
                          <input type="text" placeholder="Ex: MacBook Pro M3" value={editingItem.designation || ''} onChange={(e) => setEditingItem({...editingItem, designation: e.target.value})} className="w-full p-6 bg-slate-50 border border-slate-100 rounded-[1.5rem] font-bold outline-none focus:ring-2 focus:ring-blue-500" />
                        </div>
                        <div>
                          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Rayon</label>
                          <select value={editingItem.categorie || ''} onChange={(e) => setEditingItem({...editingItem, categorie: e.target.value})} className="w-full p-5 bg-slate-50 border border-slate-100 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="">Sélectionner</option>
                            {props.categories.map(c => <option key={c.id} value={c.designation}>{c.designation}</option>)}
                          </select>
                        </div>
                        <div>
                          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Prix (USD)</label>
                          <input type="number" placeholder="0.00" value={editingItem.prix || ''} onChange={(e) => setEditingItem({...editingItem, prix: Number(e.target.value)})} className="w-full p-5 bg-slate-50 border border-slate-100 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-blue-500" />
                        </div>
                      </div>

                      <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Description Technique</label>
                        <textarea placeholder="Spécifications détaillées..." value={editingItem.description || ''} onChange={(e) => setEditingItem({...editingItem, description: e.target.value})} className="w-full p-6 bg-slate-50 border border-slate-100 rounded-[1.5rem] font-bold h-32 outline-none focus:ring-2 focus:ring-blue-500" />
                      </div>

                      <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 ml-1">Image du Produit</label>
                        <div className="flex flex-col md:flex-row gap-6">
                          <div onClick={() => fileInputRef.current?.click()} className="flex-1 border-2 border-dashed border-slate-200 rounded-[2rem] p-8 flex flex-col items-center justify-center gap-3 cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-all group">
                            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
                            <div className="text-3xl group-hover:scale-110 transition">📸</div>
                            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Uploader</p>
                          </div>
                          {editingItem.image_url && <img src={editingItem.image_url} className="w-48 h-48 rounded-[2rem] object-cover border shadow-lg" alt="" />}
                        </div>
                      </div>
                    </>
                  )}
               </div>

               <div className="flex gap-4 mt-14">
                  <button onClick={() => setEditingItem(null)} className="flex-1 py-5 bg-slate-100 rounded-2xl font-black uppercase text-[10px] tracking-widest transition-all hover:bg-slate-200">Abandonner</button>
                  <button 
                    onClick={() => {
                      if (activeTab === 'products') props.onSaveProduct(editingItem);
                      if (activeTab === 'blog') props.onSaveBlogPost(editingItem);
                      if (activeTab === 'categories') props.onSaveCategory(editingItem);
                      if (activeTab === 'users') props.onSaveUser(editingItem);
                      setEditingItem(null);
                    }} 
                    className="flex-1 py-5 bg-blue-600 text-white rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-2xl shadow-blue-100 transition-all hover:bg-blue-700"
                  >
                    Enregistrer les données
                  </button>
               </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
