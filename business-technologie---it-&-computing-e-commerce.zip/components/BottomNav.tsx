
import React from 'react';
import { User } from '../types';

interface BottomNavProps {
  activeView: 'shop' | 'tracking' | 'admin';
  user: User | null;
  onHomeClick: () => void;
  onTrackOrderClick: () => void;
  onLoginClick: () => void;
  onAdminClick: () => void;
}

const BottomNav: React.FC<BottomNavProps> = ({
  activeView,
  user,
  onHomeClick,
  onTrackOrderClick,
  onLoginClick,
  onAdminClick
}) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 md:hidden glass border-t border-white/20 pb-safe shadow-[0_-4px_16px_rgba(0,0,0,0.05)]">
      <div className="flex justify-around items-center h-16">
        <button 
          onClick={onHomeClick}
          className={`flex flex-col items-center gap-1 transition-all ${
            activeView === 'shop' ? 'text-blue-600' : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill={activeView === 'shop' ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
          </svg>
          <span className="text-[10px] font-bold uppercase tracking-tighter">Boutique</span>
        </button>

        <button 
          onClick={onTrackOrderClick}
          className={`flex flex-col items-center gap-1 transition-all ${
            activeView === 'tracking' ? 'text-blue-600' : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill={activeView === 'tracking' ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
          </svg>
          <span className="text-[10px] font-bold uppercase tracking-tighter">Suivi</span>
        </button>

        {user?.role === 'admin' ? (
          <button 
            onClick={onAdminClick}
            className={`flex flex-col items-center gap-1 transition-all ${
              activeView === 'admin' ? 'text-orange-600' : 'text-orange-400'
            }`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill={activeView === 'admin' ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002 2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
            <span className="text-[10px] font-bold uppercase tracking-tighter">Admin</span>
          </button>
        ) : (
          <button 
            onClick={user ? () => {} : onLoginClick}
            className={`flex flex-col items-center gap-1 transition-all ${
              user ? 'text-blue-600' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <div className="w-6 h-6 rounded-full bg-slate-200 overflow-hidden border border-slate-300">
              {user ? (
                <div className="w-full h-full flex items-center justify-center bg-blue-100 text-blue-600 font-bold text-[10px]">
                  {user.nom.charAt(0)}
                </div>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full p-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              )}
            </div>
            <span className="text-[10px] font-bold uppercase tracking-tighter">
              {user ? 'Profil' : 'Compte'}
            </span>
          </button>
        )}
      </div>
    </nav>
  );
};

export default BottomNav;
