
import React from 'react';
import { ICONS } from '../constants';
import { User } from '../types';

interface HeaderProps {
  cartCount: number;
  user: User | null;
  onOpenCart: () => void;
  onOpenChat: () => void;
  onLoginClick: (initialMode?: boolean) => void;
  onLogout: () => void;
  onAdminClick: () => void;
  isAdminView: boolean;
  isTrackOrderView: boolean;
  isBlogView: boolean;
  onHomeClick: () => void;
  onTrackOrderClick: () => void;
  onBlogClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ 
  cartCount, 
  user, 
  onOpenCart, 
  onOpenChat, 
  onLoginClick, 
  onLogout, 
  onAdminClick,
  isAdminView,
  isTrackOrderView,
  isBlogView,
  onHomeClick,
  onTrackOrderClick,
  onBlogClick
}) => {
  return (
    <header className="sticky top-0 z-40 w-full glass shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center gap-2 cursor-pointer" onClick={onHomeClick}>
            <div className="bg-blue-600 p-2 rounded-lg text-white font-bold text-xl">BT</div>
            <span className="text-xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-blue-700 to-cyan-500 hidden sm:block">
              Business Technologie
            </span>
          </div>

          <nav className="hidden lg:flex space-x-8 text-sm font-medium text-slate-600">
            <button 
              onClick={onHomeClick} 
              className={`${(!isAdminView && !isTrackOrderView && !isBlogView) ? 'text-blue-600' : 'hover:text-blue-600'} transition font-semibold uppercase tracking-wider text-[11px]`}
            >
              Boutique
            </button>
            <button 
              onClick={onBlogClick} 
              className={`${isBlogView ? 'text-blue-600' : 'hover:text-blue-600'} transition font-semibold uppercase tracking-wider text-[11px]`}
            >
              Tendances & Blog
            </button>
            <button 
              onClick={onTrackOrderClick} 
              className={`${isTrackOrderView ? 'text-blue-600' : 'hover:text-blue-600'} transition font-semibold uppercase tracking-wider text-[11px]`}
            >
              Suivre Colis
            </button>
            {user?.role === 'admin' && (
              <button 
                onClick={onAdminClick}
                className={`${isAdminView ? 'text-blue-600 font-bold' : 'text-orange-600 hover:text-orange-700'} transition flex items-center gap-1 font-semibold uppercase tracking-wider text-[11px]`}
              >
                Administration
              </button>
            )}
          </nav>

          <div className="flex items-center gap-2 sm:gap-4">
            {!isAdminView && (
              <>
                <button 
                  onClick={onOpenChat}
                  className="p-2 text-slate-500 hover:bg-slate-100 rounded-full transition relative group"
                >
                  <ICONS.Robot />
                  <span className="absolute -top-1 -right-1 flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-blue-500"></span>
                  </span>
                </button>
                
                <button 
                  onClick={onOpenCart}
                  className="p-2 text-slate-500 hover:bg-slate-100 rounded-full transition relative"
                >
                  <ICONS.Cart />
                  {cartCount > 0 && (
                    <span className="absolute -top-1 -right-1 bg-blue-600 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full">
                      {cartCount}
                    </span>
                  )}
                </button>
              </>
            )}

            <div className="hidden sm:block h-6 w-px bg-slate-200 mx-1"></div>

            {user ? (
              <div className="flex items-center gap-3">
                <div className="hidden sm:block text-right">
                  <p className="text-xs font-black text-slate-900 leading-none">{user.nom}</p>
                  <p className="text-[9px] text-blue-600 font-bold uppercase tracking-widest mt-0.5">{user.role}</p>
                </div>
                <button 
                  onClick={onLogout}
                  className="p-2 text-slate-400 hover:text-red-600 transition"
                  title="Déconnexion"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                  </svg>
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => onLoginClick(false)}
                  className="hidden sm:block text-slate-600 text-xs font-bold hover:text-blue-600 px-3 py-2 transition"
                >
                  Connexion
                </button>
                <button 
                  onClick={() => onLoginClick(true)}
                  className="bg-slate-900 text-white px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-blue-600 transition shadow-lg shadow-slate-200"
                >
                  S'inscrire
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
