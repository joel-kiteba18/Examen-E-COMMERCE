
import React, { useState } from 'react';
import { CartItem, PaymentMethod, User, PaymentMethodConfig, Currency } from '../types';
import PaymentMethodSelector from './PaymentMethodSelector';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  user: User | null;
  paymentMethods: PaymentMethodConfig[];
  onRemove: (id: string) => void;
  onUpdateQuantity: (id: string, qty: number) => void;
  onCheckoutSuccess: (paymentMethod: PaymentMethod, customerPhone: string, currency: Currency, total: number) => void;
  onLoginRequest: () => void;
  onGoToTracking: () => void;
}

const CartDrawer: React.FC<CartDrawerProps> = ({ 
  isOpen, 
  onClose, 
  items, 
  user,
  paymentMethods,
  onRemove, 
  onUpdateQuantity,
  onCheckoutSuccess,
  onLoginRequest,
  onGoToTracking
}) => {
  const [step, setStep] = useState<'cart' | 'checkout' | 'success'>('cart');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(paymentMethods[0]?.id || 'mpesa');
  const [selectedCurrency, setSelectedCurrency] = useState<Currency>('USD');
  const [inputValue, setInputValue] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const exchangeRates: Record<Currency, number> = {
    'USD': 1,
    'CDF': 2500,
    'EUR': 0.92
  };

  const getCurrencySymbol = (cur: Currency) => {
    if (cur === 'USD') return '$';
    if (cur === 'EUR') return '€';
    return 'FC';
  };

  const totalBase = items.reduce((acc, item) => {
    return acc + (item.prix * item.quantity);
  }, 0);

  const convertedTotal = totalBase * exchangeRates[selectedCurrency];

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) { onLoginRequest(); return; }
    setIsProcessing(true);
    
    // Simulation du traitement de paiement
    setTimeout(() => {
      setIsProcessing(false);
      onCheckoutSuccess(paymentMethod, inputValue, selectedCurrency, convertedTotal);
      setStep('success');
      setInputValue(''); 
    }, 2500);
  };

  const renderPaymentSpecificFields = () => {
    const method = paymentMethods.find(m => m.id === paymentMethod);
    if (!method) return null;

    if (method.id === 'paypal') {
      return (
        <div className="animate-fade-in">
          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Adresse Email PayPal</label>
          <input 
            type="email" required placeholder="nom@exemple.com" value={inputValue} onChange={e => setInputValue(e.target.value)}
            className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-600 font-bold outline-none transition"
          />
          <p className="mt-2 text-[9px] text-slate-400 font-bold uppercase ml-1 italic">
            Une demande de confirmation sera envoyée sur votre compte PayPal.
          </p>
        </div>
      );
    }

    if (method.id === 'equity') {
      return (
        <div className="animate-fade-in">
          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Numéro de Compte Equity-BCDC</label>
          <input 
            type="text" required placeholder="00010-XXXXX-XXXX" value={inputValue} onChange={e => setInputValue(e.target.value)}
            className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-600 font-bold outline-none transition"
          />
          <p className="mt-2 text-[9px] text-slate-400 font-bold uppercase ml-1 italic">
            Paiement sécurisé via l'interface interbancaire Equity.
          </p>
        </div>
      );
    }

    if (method.type === 'mobile') {
      return (
        <div className="animate-fade-in">
          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Numéro de Téléphone {method.name}</label>
          <input 
            type="tel" required placeholder="Ex: +243 8..." value={inputValue} onChange={e => setInputValue(e.target.value)}
            className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-600 font-bold outline-none transition"
          />
          <p className="mt-2 text-[9px] text-slate-400 font-bold uppercase ml-1 italic">
            Validez la transaction sur votre téléphone après avoir cliqué sur "Payer".
          </p>
        </div>
      );
    }

    // Default for Cards or others
    return (
      <div className="animate-fade-in">
        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Identifiant de Paiement</label>
        <input 
          type="text" required placeholder="ID de transaction ou No de carte" value={inputValue} onChange={e => setInputValue(e.target.value)}
          className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-600 font-bold outline-none transition"
        />
      </div>
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col animate-slide-in">
        <div className="p-6 border-b flex justify-between items-center bg-slate-50/50">
          <div className="flex items-center gap-3">
            {step === 'checkout' && (
              <button onClick={() => setStep('cart')} className="p-2 hover:bg-slate-200 rounded-xl transition text-slate-600">←</button>
            )}
            <h2 className="text-xl font-black text-slate-900 uppercase tracking-tight">
              {step === 'cart' ? 'Panier' : step === 'checkout' ? 'Caisse' : 'Confirmé'}
            </h2>
          </div>
          <button onClick={onClose} className="text-slate-400">✕</button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {step === 'cart' && (
             <div className="space-y-4">
               {items.map((item) => (
                 <div key={item.id} className="flex gap-4 p-4 bg-white rounded-2xl border border-slate-100 items-center">
                    <img src={item.image_url} alt="" className="w-16 h-16 rounded-xl object-cover" />
                    <div className="flex-1">
                      <h4 className="text-sm font-black text-slate-900 leading-tight">{item.designation}</h4>
                      <p className="text-xs text-blue-600 font-black">{item.prix.toLocaleString()} {getCurrencySymbol(item.devise)}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <button onClick={() => onUpdateQuantity(item.id, Math.max(1, item.quantity - 1))} className="w-6 h-6 rounded bg-slate-100 text-xs font-bold">-</button>
                        <span className="text-xs font-bold">{item.quantity}</span>
                        <button onClick={() => onUpdateQuantity(item.id, item.quantity + 1)} className="w-6 h-6 rounded bg-slate-100 text-xs font-bold">+</button>
                      </div>
                    </div>
                    <button onClick={() => onRemove(item.id)} className="text-red-400 hover:text-red-600 p-2">✕</button>
                 </div>
               ))}
               {items.length === 0 && (
                 <div className="text-center py-20">
                    <div className="text-6xl mb-4">🛒</div>
                    <p className="text-slate-400 font-bold uppercase text-xs">Votre panier est vide</p>
                 </div>
               )}
             </div>
          )}

          {step === 'checkout' && (
            <form onSubmit={handleCheckout} className="space-y-8">
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 ml-1">Devise de facturation</label>
                <div className="grid grid-cols-3 gap-2 bg-slate-50 p-1 rounded-2xl border border-slate-100">
                  {(['USD', 'CDF', 'EUR'] as Currency[]).map((cur) => (
                    <button
                      key={cur}
                      type="button"
                      onClick={() => setSelectedCurrency(cur)}
                      className={`py-3 rounded-xl text-xs font-black transition-all ${
                        selectedCurrency === cur 
                          ? 'bg-white text-blue-600 shadow-sm border border-slate-200' 
                          : 'text-slate-400 hover:text-slate-600'
                      }`}
                    >
                      {cur}
                    </button>
                  ))}
                </div>
                <p className="text-[9px] text-slate-400 font-bold uppercase mt-2 ml-1">
                   Taux actuel : 1 USD = {exchangeRates['CDF']} CDF
                </p>
              </div>

              <PaymentMethodSelector 
                selected={paymentMethod} 
                onSelect={setPaymentMethod} 
                availableMethods={paymentMethods}
              />

              {renderPaymentSpecificFields()}

              <div className="p-6 bg-slate-900 rounded-[2rem] text-white space-y-3">
                 <div className="flex justify-between text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    <span>Total HT</span>
                    <span>{(convertedTotal * 0.84).toLocaleString()} {selectedCurrency}</span>
                 </div>
                 <div className="flex justify-between text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    <span>Taxes (16%)</span>
                    <span>{(convertedTotal * 0.16).toLocaleString()} {selectedCurrency}</span>
                 </div>
                 <div className="h-px bg-white/10 my-2"></div>
                 <div className="flex justify-between items-center">
                    <span className="text-xs font-black uppercase tracking-widest">Total à payer</span>
                    <span className="text-2xl font-black">{convertedTotal.toLocaleString()} <span className="text-blue-400 text-sm">{selectedCurrency}</span></span>
                 </div>
              </div>

              <button type="submit" disabled={isProcessing} className="w-full bg-blue-600 text-white py-5 rounded-[2rem] font-black uppercase tracking-widest hover:bg-blue-700 transition shadow-2xl shadow-blue-500/20 active:scale-95 flex items-center justify-center gap-3">
                {isProcessing ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                    Traitement sécurisé...
                  </>
                ) : `Valider le paiement`}
              </button>
            </form>
          )}

          {step === 'success' && (
            <div className="text-center py-16 animate-fade-in-up">
              <div className="w-24 h-24 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-8 border border-emerald-100 text-4xl shadow-lg">✓</div>
              <h3 className="text-3xl font-black text-slate-900 mb-4 tracking-tight uppercase">Paiement Reçu</h3>
              <p className="text-slate-500 font-medium mb-10 leading-relaxed px-4">
                Votre transaction a été validée avec succès via {paymentMethods.find(m => m.id === paymentMethod)?.name}. Votre matériel est en cours de préparation.
              </p>
              <button onClick={() => { onGoToTracking(); onClose(); }} className="w-full bg-slate-900 text-white py-5 rounded-3xl font-black uppercase tracking-widest hover:bg-blue-600 transition shadow-2xl shadow-slate-200">
                Suivre mon colis
              </button>
              <button onClick={onClose} className="w-full mt-4 py-3 text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-slate-600">Retour à la boutique</button>
            </div>
          )}
        </div>

        {step === 'cart' && items.length > 0 && (
          <div className="p-8 border-t bg-slate-50/50">
            <div className="flex justify-between items-center mb-6 px-2">
               <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Estimation</span>
               <span className="text-xl font-black text-slate-900">{totalBase.toLocaleString()} USD</span>
            </div>
            <button onClick={() => user ? setStep('checkout') : onLoginRequest()} className="w-full bg-slate-900 text-white py-5 rounded-[2rem] font-black uppercase tracking-widest hover:bg-blue-600 transition shadow-2xl shadow-slate-200 active:scale-95">Passer à la Caisse</button>
          </div>
        )}
      </div>
    </div>
  );
};

export default CartDrawer;
