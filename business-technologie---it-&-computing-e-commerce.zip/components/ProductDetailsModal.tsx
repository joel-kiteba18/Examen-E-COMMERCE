
import React, { useState } from 'react';
import { Product, User, Comment } from '../types';

interface ProductDetailsModalProps {
  product: Product;
  user: User | null;
  comments: Comment[];
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
  onLike: (productId: string) => void;
  onAddComment: (productId: string, text: string) => void;
  onLoginRequest: () => void;
}

const ProductDetailsModal: React.FC<ProductDetailsModalProps> = ({
  product,
  user,
  comments,
  isOpen,
  onClose,
  onAddToCart,
  onLike,
  onAddComment,
  onLoginRequest
}) => {
  const [commentText, setCommentText] = useState('');
  const isLiked = user ? product.likes?.includes(user.id) : false;

  if (!isOpen) return null;

  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      onLoginRequest();
      return;
    }
    if (commentText.trim()) {
      onAddComment(product.id, commentText);
      setCommentText('');
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={onClose} />
      
      <div className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col md:flex-row max-h-[90vh] animate-fade-in-up">
        {/* Image Section */}
        <div className="md:w-1/2 bg-slate-100 relative">
          <img 
            src={product.image_url} 
            alt={product.designation} 
            className="w-full h-full object-cover"
          />
          <button 
            onClick={onClose}
            className="absolute top-4 left-4 p-2 bg-white/80 backdrop-blur rounded-full hover:bg-white transition shadow-sm md:hidden"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Info & Comments Section */}
        <div className="md:w-1/2 flex flex-col h-full bg-white">
          <div className="p-6 border-b flex justify-between items-start">
            <div>
              <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest">{product.categorie}</span>
              <h2 className="text-2xl font-black text-slate-900 leading-tight">{product.designation}</h2>
            </div>
            <button onClick={onClose} className="hidden md:block p-2 hover:bg-slate-100 rounded-full transition">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-8">
            {/* Description */}
            <div>
              <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-2">À propos</h3>
              <p className="text-slate-600 leading-relaxed">{product.description}</p>
            </div>

            {/* Price & Actions */}
            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
              <div>
                <span className="text-xs text-slate-500 font-medium">Prix unitaire</span>
                <p className="text-2xl font-black text-slate-900">
                  {product.prix.toLocaleString()} <span className="text-sm text-blue-600">{product.devise === 'USD' ? '$' : product.devise === 'EUR' ? '€' : 'FC'}</span>
                </p>
              </div>
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => user ? onLike(product.id) : onLoginRequest()}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl border transition ${
                    isLiked ? 'bg-red-50 border-red-100 text-red-600' : 'bg-white border-slate-200 text-slate-400 hover:border-red-200 hover:text-red-400'
                  }`}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${isLiked ? 'fill-current' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                  </svg>
                  <span className="font-bold text-sm">{product.likes?.length || 0}</span>
                </button>
                <button 
                  onClick={() => onAddToCart(product)}
                  className="bg-blue-600 text-white px-6 py-2.5 rounded-xl font-bold hover:bg-blue-700 transition shadow-lg shadow-blue-200"
                >
                  Commander
                </button>
              </div>
            </div>

            {/* Comments Section */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest">Avis Clients ({comments.length})</h3>
              </div>
              
              <div className="space-y-4">
                {comments.length === 0 ? (
                  <p className="text-slate-400 text-sm italic text-center py-4 bg-slate-50 rounded-xl">Aucun commentaire pour le moment. Soyez le premier !</p>
                ) : (
                  comments.map((comment) => (
                    <div key={comment.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-bold text-slate-900">{comment.nom_client}</span>
                        <span className="text-[10px] text-slate-400">{new Date(comment.date).toLocaleDateString()}</span>
                      </div>
                      <p className="text-sm text-slate-600">{comment.texte}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Comment Input */}
          <div className="p-4 border-t bg-slate-50">
            <form onSubmit={handleSubmitComment} className="flex gap-2">
              <input 
                type="text" 
                placeholder={user ? "Votre avis sur ce produit..." : "Connectez-vous pour commenter"}
                disabled={!user}
                className="flex-1 px-4 py-2 rounded-xl border border-slate-200 bg-white outline-none focus:ring-2 focus:ring-blue-600 transition text-sm disabled:opacity-50"
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
              />
              <button 
                type="submit"
                disabled={!user || !commentText.trim()}
                className="p-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition disabled:opacity-50"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                </svg>
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailsModal;
