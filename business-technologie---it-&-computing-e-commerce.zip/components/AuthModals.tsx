
import React, { useState, useEffect } from 'react';
import { User } from '../types';

interface AuthModalsProps {
  isOpen: boolean;
  initialRegisterMode?: boolean;
  onClose: () => void;
  onLoginSuccess: (user: User) => void;
}

export const AuthModal: React.FC<AuthModalsProps> = ({ 
  isOpen, 
  initialRegisterMode = false,
  onClose, 
  onLoginSuccess 
}) => {
  const [isRegister, setIsRegister] = useState(initialRegisterMode);
  const [mail, setMail] = useState('');
  const [password, setPassword] = useState('');
  const [nom, setNom] = useState('');
  const [error, setError] = useState('');

  // Synchroniser le mode si la modale est rouverte via un bouton spécifique
  useEffect(() => {
    setIsRegister(initialRegisterMode);
  }, [initialRegisterMode, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Admin check (Simulation de validation Supabase Auth)
    if (!isRegister && mail === 'joelyombikale@gmail.com' && password === '12345678') {
      onLoginSuccess({
        id: 'admin-1',
        mail: 'joelyombikale@gmail.com',
        nom: 'Joel Yombikale',
        mot_de_passe: '12345678',
        role: 'admin',
        inscription: new Date().toISOString()
      });
      onClose();
      return;
    }

    if (isRegister) {
      if (!nom || !mail || !password) {
        setError('Veuillez remplir tous les champs');
        return;
      }
      onLoginSuccess({
        id: Math.random().toString(36).substr(2, 9),
        mail,
        nom,
        mot_de_passe: password,
        role: 'user',
        inscription: new Date().toISOString()
      });
      onClose();
    } else {
      if (mail && password.length >= 6) {
        onLoginSuccess({
          id: Math.random().toString(36).substr(2, 9),
          mail,
          nom: mail.split('@')[0],
          mot_de_passe: password,
          role: 'user',
          inscription: new Date().toISOString()
        });
        onClose();
      } else {
        setError('Identifiants invalides (min. 6 caractères)');
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl overflow-hidden animate-fade-in-up">
        <div className="p-8">
          <div className="flex bg-slate-100 p-1.5 rounded-2xl mb-8">
            <button 
              onClick={() => setIsRegister(false)}
              className={`flex-1 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${!isRegister ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
            >
              Connexion
            </button>
            <button 
              onClick={() => setIsRegister(true)}
              className={`flex-1 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${isRegister ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
            >
              S'inscrire
            </button>
          </div>

          <h2 className="text-2xl font-black text-slate-900 mb-2 tracking-tight">
            {isRegister ? 'Rejoindre BT' : 'Bon retour !'}
          </h2>
          <p className="text-slate-500 text-sm mb-8 font-medium">
            {isRegister ? 'Créez votre compte Business Technologie en 1 minute.' : 'Accédez à votre espace membre et vos commandes.'}
          </p>

          <form onSubmit={handleSubmit} className="space-y-5">
            {isRegister && (
              <div className="animate-fade-in">
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Nom Complet</label>
                <input 
                  type="text" 
                  value={nom}
                  onChange={(e) => setNom(e.target.value)}
                  className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-600 transition font-bold"
                  placeholder="Joel Yombikale"
                />
              </div>
            )}
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Email Professionnel</label>
              <input 
                type="email" 
                value={mail}
                onChange={(e) => setMail(e.target.value)}
                className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-600 transition font-bold"
                placeholder="votre@mail.com"
                required
              />
            </div>
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Mot de Passe</label>
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-600 transition font-bold"
                placeholder="••••••••"
                required
              />
            </div>

            {error && (
              <div className="bg-red-50 text-red-600 px-4 py-2 rounded-xl text-xs font-bold border border-red-100 animate-pulse">
                {error}
              </div>
            )}

            <button 
              type="submit" 
              className="w-full bg-slate-900 text-white py-4 rounded-2xl font-black uppercase tracking-widest hover:bg-blue-600 transition shadow-xl shadow-slate-200 active:scale-95"
            >
              {isRegister ? "Créer mon compte" : 'Entrer'}
            </button>
          </form>

          <p className="mt-8 text-center text-[10px] text-slate-400 font-bold uppercase tracking-wider">
            Sécurisé par Business Technologie Cloud
          </p>
        </div>
      </div>
    </div>
  );
};
