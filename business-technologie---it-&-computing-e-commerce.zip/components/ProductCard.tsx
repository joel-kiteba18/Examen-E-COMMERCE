
import React from 'react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onViewDetails: (product: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart, onViewDetails }) => {
  const getCurrencySymbol = (devise: string) => {
    switch (devise) {
      case 'USD': return '$';
      case 'EUR': return '€';
      case 'CDF': return 'FC';
      default: return devise;
    }
  };

  return (
    <div className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-slate-100 flex flex-col h-full">
      <div className="aspect-square overflow-hidden bg-slate-100 relative cursor-pointer" onClick={() => onViewDetails(product)}>
        <img 
          src={product.image_url} 
          alt={product.designation}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-3 left-3 flex gap-2">
          <span className="bg-white/90 backdrop-blur px-2 py-1 rounded text-[10px] font-bold uppercase text-slate-600 shadow-sm">
            {product.categorie}
          </span>
        </div>
        
        {product.likes && product.likes.length > 0 && (
          <div className="absolute bottom-3 right-3 bg-white/90 backdrop-blur px-2 py-1 rounded-full text-[10px] font-bold text-red-500 flex items-center gap-1 shadow-sm">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 fill-current" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
            </svg>
            {product.likes.length}
          </div>
        )}
      </div>

      <div className="p-5 flex flex-col flex-1">
        <h3 className="font-semibold text-slate-900 group-hover:text-blue-600 transition line-clamp-1 cursor-pointer" onClick={() => onViewDetails(product)}>
          {product.designation}
        </h3>
        <p className="text-sm text-slate-500 mt-1 line-clamp-2 h-10 flex-1">
          {product.description}
        </p>
        
        <div className="mt-4">
          <div className="text-xl font-bold text-slate-900 mb-4">
            {product.prix.toLocaleString()} <span className="text-sm text-blue-600 ml-1">{getCurrencySymbol(product.devise)}</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button 
              onClick={() => onViewDetails(product)}
              className="bg-slate-100 text-slate-600 px-3 py-2 rounded-xl text-xs font-bold hover:bg-slate-200 transition"
            >
              Détails
            </button>
            <button 
              onClick={() => onAddToCart(product)}
              className="bg-slate-900 text-white px-3 py-2 rounded-xl text-xs font-bold hover:bg-blue-600 transition active:scale-95"
            >
              Ajouter
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
